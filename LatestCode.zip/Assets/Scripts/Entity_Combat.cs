using System;
using UnityEngine;
using System.Diagnostics;
using Debug = UnityEngine.Debug;

public class Entity_Combat : MonoBehaviour
{
    public Collider2D[] targetColliders;

    [Header("Target Detection")]
    [SerializeField]
    private Transform targetCheck;
    [SerializeField]
    private float targetCheckRadius;
    [SerializeField]
    private LayerMask whatIsTarget;

    public void PerformAttack()
    {
        GetDetectedColliders();


        foreach (var target in targetColliders)
        {
            Debug.Log($"Detected {target.name}");
        }
    }

    private void GetDetectedColliders()
    {
        targetColliders = Physics2D.OverlapCircleAll(transform.position, targetCheckRadius, whatIsTarget);
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(targetCheck.position, targetCheckRadius);
    }
}