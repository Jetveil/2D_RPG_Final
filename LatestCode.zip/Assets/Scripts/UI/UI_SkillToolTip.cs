using TMPro;
using UnityEngine;

public class UI_SkillToolTip : UI_Tooltip
{
    [SerializeField] private TextMeshProUGUI skillName;
    [SerializeField] private TextMeshProUGUI skillDescription;
    [SerializeField] private TextMeshProUGUI skillRequirements;

    public override void ShowTooltip(bool show, RectTransform targetRect)
    {
        base.ShowTooltip(show, targetRect);
    }

    public void ShowTooltip(bool show, RectTransform targetRect, Skill_DataSO skillData)
    {
        base.ShowTooltip(show, targetRect);

        if (show == false)
            return;

        skillName.text = skillData.displayedName;
        skillDescription.text = skillData.description;
        skillRequirements.text = $"Requirements: \n " +
                                 $"- {skillData.cost} points";
    }
}