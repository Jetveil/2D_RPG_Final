using UnityEngine;

public class UI_TreeConnection : MonoBehaviour
{

}


public enum NodeDirectionType
{
    None,
    UpLeft,
    Up,
    UpRight,
    Right,
    DownRight,
    Down,
    DownLeft,
    Left
}